<?php
use yii\helpers\Html;
/* @var $this yii\web\View */

$this->title = 'My Yii Application';
?>
<div class="site-index">

    <div class="jumbotron">
        <h1>Smart Apps</h1>
        <p class="lead">Aplikasi Absensi Berbasis Web.</p>
        <div class="row">        	
        <?= Html::img('@web/images/img1.jpg') ?>
        <?= Html::img('@web/images/img2.png') ?>
        </div>

    </div>

    <div class="body-content">

        

    </div>
</div>
