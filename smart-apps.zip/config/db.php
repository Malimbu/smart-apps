<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=kampus',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8',
];
